import java.io.IOException;
import java.util.*;
import org.apache.hadoop.io.IntWritable; 
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.LongWritable; 
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CleanMapper 
    extends Mapper<LongWritable, Text, Text, NullWritable> {

    private final static IntWritable one = new IntWritable(1);
    private Text word = new Text();

    
    @Override
    public void map(LongWritable key, Text value, Context context) 
        throws IOException, InterruptedException {
        
        if (value.toString().startsWith("State")) {
            return;
        }
        String line = value.toString();
        String[] tokens = line.split(",", 0);

        StringBuilder sb = new StringBuilder();
        int[] colToKeep = new int[] {0,1,2,9,10,11};
        for(int i : colToKeep){
            String token = tokens[i];
            int totalLength = token.length();
            token=token.trim();
            sb.append(token);
            if(i<11)
                sb.append(',');  
        }
        word.set(sb.toString());
        
        context.write(word, NullWritable.get());
    }
        
        
        
        
    }

    

